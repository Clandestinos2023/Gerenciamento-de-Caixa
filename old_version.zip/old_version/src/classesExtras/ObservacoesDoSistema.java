/**
 *  COISAS A IMPLANTAR:
 *      -carrinho de compras;
 *      -controle de estoque;
 *      -BD online;
 *      -
 *      -
 *      
 * 
 *  FUNCIONALIDADES:
 *      -RG para facilitar em alguma emergência;
 *      -Controle do caixa da cantina;
 *      -
 *      -
 *      -
 *      -
 *      -   
 * 
 *  
 *  
 */
